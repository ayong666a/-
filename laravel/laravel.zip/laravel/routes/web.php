<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::any('/php','Test\TestController@php');
Route::any('/goods','Test\TestController@goods');
Route::any('/goodsDo','Test\TestController@goodsDo');
Route::any('/list','Test\TestController@list');
Route::get('/dele','Test\TestController@dele');
Route::get('/upda','Test\TestController@upda');
Route::any('/updaDo','Test\TestController@updaDo');
Route::any('/update','Test\TestController@update');

Route::any('/index','User\IndexController@index');
Route::any('/login','User\LoginController@login');
Route::any('/register','User\RegisterController@register');
Route::post('/doadd','User\RegisterController@doadd');
Route::post('/loginDo','User\loginController@loginDo');
Route::post('/sendcode','User\RegisterController@sendcode');
Route::any('/load','User\IndexController@load');
Route::any('/lottery','User\LotteryController@lottery');
Route::post('/getid','User\LotteryController@getid');
Route::any('/shopli','User\LotteryController@getid');
Route::any('/shopcount','User\ShopcountController@details');
Route::post('/getgoodsid','User\ShopcountController@getgoodsid');
Route::any('/paycart','User\PaycartController@paycart');
Route::post('/delgoods','User\PaycartController@delgoods');
Route::post('/creatup','User\PaycartController@creatup');
Route::post('/delup','User\PaycartController@delup');
Route::post('/pdelGoods','User\PaycartController@pdelGoods');
Route::post('/jiance','User\PaycartController@jiance');
Route::post('/payall','User\PaycartController@payall');
Route::any('/payment','User\PaymentController@pay');
Route::any('/address','User\AddressController@address');
Route::any('/writeaddr','User\WriteaddrController@writeaddr');
Route::any('/addressinfo','User\WriteaddrController@addressinfo');
Route::any('/moren','User\AddressController@moren');
Route::post('/deladdress','User\AddressController@deladdress');
Route::any('/updateaddre','User\AddressController@updateaddre');





