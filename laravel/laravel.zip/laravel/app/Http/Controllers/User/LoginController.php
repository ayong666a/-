<?php

namespace App\Http\Controllers\User;
use App\Model\UserModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

/**
 * Class LoginController
 * @package App\Http\Controllers\User
 * 登录
 */
class LoginController extends Controller{

	public function login(){
		return view("user.login");
	}

	public function loginDo(Request $request){
	    $data=$request->input();
        $tel=$data['tel'];
        $pwd=$data['pwd'];
        $pwd=md5($pwd);
        $where=[
            'name'=>$tel,
            'pwd'=>$pwd
        ];
	    $arr=DB::table('user')->where($where)->first();
	        if($arr){
	            $id=$arr->id;
	            $name=$arr->name;
	            session(["id"=>$id,"name"=>$name]);
	            $array=[
	                'status'=>1,
	                "msg"=>"登录成功"
	            ];
	            return $array;
	        }else{
	            $array=[
	                'status'=>0,
	                "msg"=>"手机号或密码错误"
	            ];
                return $array;
	        }

	}
}