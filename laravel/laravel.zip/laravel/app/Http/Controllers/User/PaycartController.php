<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Goods;
use App\Model\Buy;
class PaycartController extends Controller
{
    public function paycart()
    {
        {/*购物车数据*/}
        $goodsinfo = DB::table('goods')
            ->join('buy', 'goods.goods_id', '=', 'buy.goods_id')
            ->where('status', 1)
            ->get();
        //dump($goodsinfo);
        //人气推荐
        $goodsinfos = DB::table('goods')
            ->where('goods_hot', 1)
            ->get();
        //dump($goodsinfos);
        return view('user.paycart', ['goodsinfo' => $goodsinfo, 'goodsinfos' => $goodsinfos]);
    }
    //不能为负数
    public function jiance(Request $request){
        $goods_num=$request->input('goods_num');
        if($goods_num<0){
            $array=[
                'status'=>0,
                'msg'=>"请输入正常数据"
            ];
            return $array;
        }
    }
    //加
    public function creatup(Request $request){
        $uid=session('id');
        $goods_num=$request->input('goods_num');
        $goods_id=$request->input('goods_id');
        //入库
        $where=[
            'goods_id'=>$goods_id,
            'uid'=>$uid
        ];
        $upnum=[
            'buy_num'=>$goods_num
        ];
        $delgoods=DB::table('buy')->where($where)->update($upnum);
    }
    //减
    public function delup(Request $request){
        $uid=session('id');
        $goods_num=$request->input('goods_num');
        $goods_id=$request->input('goods_id');
        //入库
        $where=[
            'goods_id'=>$goods_id,
            'uid'=>$uid
        ];
        $delnum=[
            'goods_num'=>$goods_num
        ];
        $delgoods=DB::table('buy')->where($where)->update($delnum);

    }
    //单删
    public function delgoods(Request $request){
        $delid=$request->input('delid');
        $status=[
            'status'=>0
        ];
        $delgoods=DB::table('buy')->where('goods_id',$delid)->update($status);
        if($delgoods){
            $array=[
                'status'=>0,
                'msg'=>"删除成功"
            ];
            return $array;
        }
    }
    //批删
    public function pdelGoods(Request $requset){
        $tr = $requset->input('tr');
        //去右逗号
        $_tr = rtrim($tr,',');
        //变成数组
        $ttr = explode(',',$_tr);
        //循环
        $status=[
            'status'=>0
        ];
        foreach($ttr as $k=>$v){
            DB::table('buy')->where('goods_id',$v)->update($status);
        }
        $array=[
            'status'=>0,
            'msg'=>"删除成功"
        ];
        return $array;
    }
    //提交订单
    public function payall(Request $requset){
        $goods_id= $requset->input('goods_id');
        $goods_price= $requset->input('price');
        $goods_price= trim($goods_price,'￥');
        //商品是否为空
        if (empty($goods_id)){
            $array=[
                'status'=>0,
                'msg'=>"商品不能为空"
            ];
            return $array;
        }else{
            //是否登录
            $uid=session('id');
            if (empty($uid)){
                $array=[
                    'status'=>1,
                    'msg'=>"请先登录"
                ];
                return $array;
            }else{
                //判断库存
                $data=[];
                $info=DB::table('goods')
                    ->join('buy','goods.goods_id','=','buy.goods_id')
                    ->whereIn('goods.goods_id',$goods_id)
                    ->get();
                //dump($info);
                foreach ($info as $k=>$v){
                    if ($v->buy_num<$v->goods_num){

                    }else{
                        $array=[
                            'status'=>0,
                            'msg'=>"库存不足"
                        ];
                        return $array;
                    }
                }
                //生成订单号
                $order_num=date("YmdHis".time()).rand(1000,9999);
                $uid=session('id');
                $orderinfo=[
                    'order_num'=>$order_num,
                    'user_id'=>$uid,
                    'order_count'=>$goods_price,
                    'ctime'=>time()
                ];
                $res=DB::table('order')->insert($orderinfo);
                //生成详情表
                $orderdetails=DB::table('order')->where('order_num',$order_num)->get(['order_id']);
                //dump($info);
                foreach ($info as $v){
                    $arr=[
                        'order_id'=>$orderdetails[0]->order_id,
                        'user_id'=>$uid,
                        'order_num'=>$order_num,
                        'goods_id'=>$v->goods_id,
                        'goods_name'=>$v->goods_name,
                        'goods_selfprice'=>$v->goods_selfprice,
                        'goods_img'=>$v->goods_img,
                        'goods_status'=>1,
                        'ctime'=>time()
                ];
                    DB::table('order_details')->insert($arr);
                }
                $ress=DB::table('buy')
                    ->whereIn('goods_id',$goods_id)
                    ->where('uid',$uid)
                    ->update(['status'=>2,'buy_num'=>0]);

                if ($res&&$ress){
                    $array=[
                        'status'=>2,
                        'msg'=>"提交成功"
                    ];
                    return $array;
                }
            }


        }





    }


}