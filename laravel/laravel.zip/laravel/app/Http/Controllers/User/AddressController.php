<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Goods;
use App\Model\Buy;
class AddressController extends Controller
{
    public function address(){
        $res=DB::table('address')->where('is_del',0)->get();
        return view('user.address',['res'=>$res]);
    }
    //默认值
    public function moren(Request $request){
        $use_id=$request->input('use_id');
        //修改默认值
        $user_id=session('id');
        //查询默认
        $allstatus=DB::table('address')
            ->where('user_id',$user_id)
            ->select(['use_status'])
            ->get();
        //清除默认
        $status=[
            'use_status'=>0
        ];
        foreach($allstatus as $k=>$v){
            DB::table('address')->update($status);
        };
        //入库
        $where=[
            'use_id'=>$use_id,
            'user_id'=>$user_id
        ];
        $addinfo=[
            'use_status'=>1
        ];
        DB::table('address')->where($where)->update($addinfo);




    }
    //删除
    public function deladdress(Request $request){
        $use_id=$request->input('use_id');
        $updata=[
            'is_del'=>1
        ];
        $res=DB::table('address')->where('use_id',$use_id)->update($updata);
        if ($res){
            $array=[
                'code'=>1,
                'font'=>'删除成功'
            ];
            return $array;
        }else{
            $array=[
                'code'=>0,
                'font'=>'删除失败'
            ];
            return $array;
        }
    }
    //修改
    public function updateaddre(Request $request){
        $use_id=$request->input('use_id');
        $res=DB::table('address')->where('use_id',$use_id)->get();
        return view('user.updateaddre',['res'=>$res]);
    }
}