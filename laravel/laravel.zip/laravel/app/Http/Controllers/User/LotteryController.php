<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Category;
use App\Model\Goods;

class LotteryController extends Controller{
    //视图
    public function lottery(){
        //顶级分类
        $cateinfo=Category::where('pid',0)->get();
        $arrr=Goods::where('goods_up',1)->get();
        return view('user.lottery',['cateinfo'=>$cateinfo,'arrr'=>$arrr]);
    }

    //点击分类出数据
    public function getid(Request $request){
        $arr=array();
        //获取顶级分类ID
        $cateid=$request->input('cate_id');
        $goodsinfo=Goods::orderBy('goods_selfprice','desc');
        //var_dump($goodsinfo);
        if ($cateid){
            $cateinfo=Category::get();
            $cateid=$this->getcateid($cateinfo,$cateid);
            $goodsinfo=$goodsinfo->whereIn('cate_id',$cateid);
        }
            $alll=$goodsinfo->get();

            $liview=view('user.shopli',['alll'=>$alll]);
            $countent=response($liview)->getContent();
            $arr['info']=$countent;
            return $arr;
    }
    //递归
    public function getcateid($cateinfo,$pid){
        static $cateId=[];
        foreach ($cateinfo as $k=>$v){
            if ($v['pid']==$pid){
                $cateId[]=$v['cate_id'];
                $this->getcateid($cateinfo,$v['cate_id']);
            }
        }
        return $cateId;
    }
}
