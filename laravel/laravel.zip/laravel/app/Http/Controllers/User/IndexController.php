<?php

namespace App\Http\Controllers\User;
use App\Model\UserModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

/**
 * Class LoginController
 * @package App\Http\Controllers\User
 * index
 */
class IndexController extends Controller{

	public function index(){
        //潮人推荐
        $arr=DB::table('goods')->limit(2)->get();
		//猜你喜欢
        $data = DB::table('goods')->get();
        return view("user.index",["data"=>$data,'arr'=>$arr]);

	}
	public function load(Request $request){
//        $data = DB::table('shop_goods')->get();
//	    return view("user.load");
        $arr=array();
        $page=$request->input("page",1);
        $pageNum=2;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table("goods")->offset($offset)->limit($pageNum)->get();//每页的数据

        $totalData=DB::table("goods")->count();
        $pageTotal=ceil($totalData/$pageNum);//总页数

        $objview=view("user.load",['arrDataInfo'=>$arrDataInfo]);
        $content=response($objview)->getContent();

        $arr['info']=$content;
        $arr['page']=$pageTotal;
        return $arr;
    }

}