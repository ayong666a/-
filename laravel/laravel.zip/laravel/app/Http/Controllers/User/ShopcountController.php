<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Goods;
use App\Model\Buy;

class ShopcountController extends Controller{
    public function details(Request $request){
        //详情数据
        $goods_id=$request->input('goods_id');
        $shopinfo=Goods::where('goods_id',$goods_id)->get();
        return view('user.shopcount',['shopinfo'=>$shopinfo]);
    }
    //判断数据
    public function getgoodsid(Request $request){
        $goods_id=$request->input('goods_id');
        $goods_num=$request->input('goods_num');

        $where=[
            'goods_id'=>$goods_id,
            'goods_up'=>1
        ];
        //是否上架
        $shop_goods=Goods::where($where)->first()->toArray();
//        print_r($shop_goods);die;
        if(empty($shop_goods)){
            $array=[
                'status'=>0,
                'msg'=>"此商品已下架"
            ];
            return $array;
        }
        //是否登录
        $name=session('name');
        $uid=session('id');
        if (empty($uid)){
            $array=[
                'status'=>1,
                'msg'=>"请先登录"
            ];
            return $array;
        }
        //判断库存
        //dump($shop_goods);
        if($shop_goods['goods_num']==0){
            $array=[
                'status'=>0,
                'msg'=>"库存不足"
            ];
            return $array;
        }
        $where=[
            'uid'=>$uid,
            'goods_id'=>$goods_id
        ];
        $shop_num=DB::table('buy')->where($where)->first();
        //dump($shop_num);
        if (empty($shop_num->buy_num)){
            $data=[
                'goods_id'=>$goods_id,
                'uid'=>$uid,
                'goods_num'=>$goods_num,
                'status'=>1,
                'create_time'=>time()
            ];
            Buy::insert($data);
        }else{
            $num=$shop_num->buy_num;
            $updateInfo=[
                'buy_num'=>$num+1,
            ];
            $buy=Buy::where($where)->update($updateInfo);


        }
        $array=[
            'status'=>2,
            'msg'=>"添加成功"
        ];
        return $array;
    }
}