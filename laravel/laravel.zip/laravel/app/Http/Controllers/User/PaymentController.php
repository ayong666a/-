<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Goods;
use App\Model\Buy;
class PaymentController extends Controller
{
    public function pay(){
        return view('user.payment');
    }
}