<?php
namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Model\Goods;
use App\Model\Buy;
class WriteaddrController extends Controller
{
    public function writeaddr(){
        return view('user.writeaddr');
    }
    //添加地址
    public function addressinfo(Request $request){
        $addressinfo=$request->input();
        $use_name=$addressinfo['use_name'];
        $use_tel=$addressinfo['use_tel'];
        $use_city=$addressinfo['use_city'];
        $city_details=$addressinfo['city_details'];
        $use_status=$addressinfo['use_status'];

        $user_id=session('id');
        if(empty($user_id)){
            $array=[
                'status'=>2,
                'msg'=>"请先登录"
            ];
            return $array;
        }
        //验证数据不能为空
        if (empty($use_name)){
            $array=[
                'status'=>0,
                'msg'=>"收货人不能为空"
            ];
            return $array;
        }
        if (empty($use_tel)){
            $array=[
                'status'=>0,
                'msg'=>"电话号不能为空"
            ];
            return $array;
        };
        if (empty($use_city)){
            $array=[
                'status'=>0,
                'msg'=>"所在区域不能为空"
            ];
            return $array;
        };
        if (empty($city_details)){
            $array=[
                'status'=>0,
                'msg'=>"详细地址不能为空"
            ];
            return $array;
        };
        //设置默认
        if ($use_status==1){
            //查询默认
            $allstatus=DB::table('address')
                ->where('user_id',$user_id)
                ->select(['use_status'])
                ->get();
            //清除默认
            $status=[
                'use_status'=>0
            ];
            foreach($allstatus as $k=>$v){
                DB::table('address')->update($status);
            }
        }
        //入库
        $addinfo=[
            'user_id'=>$user_id,
            'use_name'=>$use_name,
            'use_tel'=>$use_tel,
            'use_city'=>$use_city,
            'city_details'=>$city_details,
            'use_status'=>$use_status,
            'is_del'=>0
        ];
        $res=DB::table('address')->insert($addinfo);
        if ($res){
            $array=[
                'status'=>1,
                'msg'=>"添加成功"
            ];
            return $array;
        }




    }

}