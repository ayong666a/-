<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        a{text-decoration:none;}
    </style>

</head>
<body>
    <table border="1">
        <tr>
            <td>ID</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否上架</td>
            <td>是否热卖</td>
            <td>操作</td>
        </tr>
        <tbody id="tbody">
            @foreach($data as $k=>$v)
                <tr>
                    <td>{{$v->id}}</td>
                    <td><input type="text" name="up" value="{{$v->name}}" id="{{$v->id}}"></td>
                    <td>{{$v->cate}}</td>
                    <td>{{$v->describe}}</td>
                    <td>{{$v->is_putaway}}</td>
                    <td>{{$v->ishot}}</td>
                    <td>
                        <a href="javaScript:;" class="d" dele="{{$v->id}}">删除</a>
                        <a href="/upda?upda={{$v->id}}">修改</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div  id="a">
        {{ $data->links() }}
    </div>{{--style="height: 20px;width: 100%;margin: 0 auto;position: fixed;left: 50%;"--}}
    <script src="/laravel/public/js/jquery.js"></script>
    <script>
        $(function(){
            $('#a').find('li').addClass('a');
        });
    </script>
    <style>
        .a{
            float: left;
            margin: 10px;
        }
    </style>
</body>
</html>
<script>
    $(function(){
        $(".d").on('click',function(){
            var dele=$(this).attr('dele');
            $.ajax({
               url:"/dele",
                data:{dele:dele},
                type:"get",
                async:true,
                dataType:'json',
                success:function(msg){
                   if(msg == 1){
                       location.href="/list";
                   }else{
                       location.href="/list";
                   }

                }
            });
        })
        //即点即改
        $('input[name=up]').blur(function(){
            var _this=$(this);
            var id=$(this).prop('id');
            //console.log(id);
            var name=$('input[name=up]').val();
            //console.log(name);
            $.post('update',{id:id,name:name},function(msg){
                if(msg==1){
                    alert('修改成功');
                }else{
                    alert('修改失败');
                }
            })
        });
    })
</script>