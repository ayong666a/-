<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="" method="post">
		<table>
			<tr>
				<td>名称</td>
				<td><input type="text"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td><select><option value=""></option></select></td>
			</tr>
			<tr>
				<td>描述</td>
				<td><input type="textarea"></td>
			</tr>
			<tr>
				<td>是否热卖</td>
				<td><input type="radio">是<input type="radio">否</td>
			</tr>
			<tr>
				<td>是否上架</td>
				<td><input type="radio">是<input type="radio">否</td>
			</tr>
			<tr>
				<td><input type="submit" value="确认"></td>
			</tr>
		</table>
	</form>
</body>
</html>