<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.min.js"></script>
</head>
<body>
    <table border="1">
        <tr>
            <td>名称</td>
            <td><input type="text" id="name"></td>
        </tr>
        <tr>
            <td>分类</td>
            <td>
                <select id="cate">
                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v->name); ?>"><?php echo e($v->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>描述</td>
            <td>
                <input type="text" id="describe">
            </td>
        </tr>
        <tr>
            <td>是否上架</td>
            <td>
                <input type="radio" name="is_putaway" value="1">是
                <input type="radio" name="is_putaway" value="2">否
            </td>
        </tr>
        <tr>
            <td>是否热卖</td>
            <td>
                <input type="radio" name="ishot" value="1">是
                <input type="radio" name="ishot" value="2">否
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" id="sub"></td>
        </tr>
    </table>
</body>
</html>
<script type="text/javascript">
    $(function(){
        $("#sub").on("click",function(){
            var name=$("#name").val();
            var cate=$("#cate").val();
            var describe=$("#describe").val();
            var is_putaway=$("input[name='is_putaway']:checked").val();
            var ishot=$("input[name='ishot']:checked").val();
            //ajax
            $.ajax({
                url:"/goodsDo",
                data:{name:name,cate:cate,describe:describe,is_putaway:is_putaway,ishot:ishot},
                type:"post",
                async:true,
                success:function(msg){

                    if(msg == "OK" ){
                        location.href="/list";
                    }else{
                        location.href="/goods";
                    }
                }
            });
        })
    })
</script>